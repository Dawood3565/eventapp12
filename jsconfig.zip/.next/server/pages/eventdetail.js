/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/eventdetail";
exports.ids = ["pages/eventdetail"];
exports.modules = {

/***/ "./styles/joinevent.module.css":
/*!*************************************!*\
  !*** ./styles/joinevent.module.css ***!
  \*************************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvam9pbmV2ZW50Lm1vZHVsZS5jc3MuanMiLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTs7QUFFQSIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL3N0eWxlcy9qb2luZXZlbnQubW9kdWxlLmNzcz9mNGRkIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXG59O1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./styles/joinevent.module.css\n");

/***/ }),

/***/ "./pages/eventdetail.js":
/*!******************************!*\
  !*** ./pages/eventdetail.js ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_joinevent_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../styles/joinevent.module.css */ \"./styles/joinevent.module.css\");\n/* harmony import */ var _styles_joinevent_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_joinevent_module_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _pages_firebase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../pages/firebase */ \"./pages/firebase.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_firebase__WEBPACK_IMPORTED_MODULE_2__]);\n_pages_firebase__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\nconst seedetail = ()=>{\n    const [details, setDetails] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        async function fetchEventsData() {\n            const querySnapshot = await (0,_pages_firebase__WEBPACK_IMPORTED_MODULE_2__.getDocs)((0,_pages_firebase__WEBPACK_IMPORTED_MODULE_2__.collection)(_pages_firebase__WEBPACK_IMPORTED_MODULE_2__.db, \"events\"));\n            const eventsData = querySnapshot.docs.map((doc)=>({\n                    id: doc.id,\n                    ...doc.data()\n                }));\n            setDetails(eventsData);\n        }\n        fetchEventsData();\n    }, []);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: (_styles_joinevent_module_css__WEBPACK_IMPORTED_MODULE_3___default().cardcontainer),\n        children: details.map((event)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: (_styles_joinevent_module_css__WEBPACK_IMPORTED_MODULE_3___default().card),\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: (_styles_joinevent_module_css__WEBPACK_IMPORTED_MODULE_3___default().cardbody),\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h2\", {\n                            className: (_styles_joinevent_module_css__WEBPACK_IMPORTED_MODULE_3___default().cardtitle),\n                            children: event.title\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\eventdetail.js\",\n                            lineNumber: 20,\n                            columnNumber: 13\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                            className: (_styles_joinevent_module_css__WEBPACK_IMPORTED_MODULE_3___default().carddiscription),\n                            children: event.description\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\eventdetail.js\",\n                            lineNumber: 21,\n                            columnNumber: 13\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                            className: (_styles_joinevent_module_css__WEBPACK_IMPORTED_MODULE_3___default().carddate),\n                            children: event.date\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\eventdetail.js\",\n                            lineNumber: 22,\n                            columnNumber: 13\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                            className: (_styles_joinevent_module_css__WEBPACK_IMPORTED_MODULE_3___default().location),\n                            children: event.location\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\eventdetail.js\",\n                            lineNumber: 23,\n                            columnNumber: 13\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                            className: (_styles_joinevent_module_css__WEBPACK_IMPORTED_MODULE_3___default().time),\n                            children: event.time\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\eventdetail.js\",\n                            lineNumber: 24,\n                            columnNumber: 13\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                            className: (_styles_joinevent_module_css__WEBPACK_IMPORTED_MODULE_3___default().invitees),\n                            children: event.invitees\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\eventdetail.js\",\n                            lineNumber: 25,\n                            columnNumber: 13\n                        }, undefined)\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\eventdetail.js\",\n                    lineNumber: 19,\n                    columnNumber: 11\n                }, undefined)\n            }, event.id, false, {\n                fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\eventdetail.js\",\n                lineNumber: 18,\n                columnNumber: 9\n            }, undefined))\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\eventdetail.js\",\n        lineNumber: 16,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (seedetail);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9ldmVudGRldGFpbC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBNEM7QUFDUTtBQUNPO0FBQzNELE1BQU1PLFlBQVksSUFBTTtJQUN0QixNQUFNLENBQUNDLFNBQVNDLFdBQVcsR0FBR1IsK0NBQVFBLENBQUMsRUFBRTtJQUN6Q0QsZ0RBQVNBLENBQUMsSUFBTTtRQUNkLGVBQWVVLGtCQUFrQjtZQUMvQixNQUFNQyxnQkFBZ0IsTUFBTU4sd0RBQU9BLENBQUNDLDJEQUFVQSxDQUFDSCwrQ0FBRUEsRUFBRTtZQUNuRCxNQUFNUyxhQUFhRCxjQUFjRSxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDVixNQUFTO29CQUFFVyxJQUFJWCxJQUFJVyxFQUFFO29CQUFFLEdBQUdYLElBQUlZLElBQUksRUFBRTtnQkFBQztZQUNoRlAsV0FBV0c7UUFDYjtRQUVBRjtJQUNGLEdBQUcsRUFBRTtJQUNMLHFCQUNFLDhEQUFDTztRQUFJQyxXQUFXaEIsbUZBQW9CO2tCQUNqQ00sUUFBUU0sR0FBRyxDQUFDLENBQUNNLHNCQUNaLDhEQUFDSDtnQkFBSUMsV0FBV2hCLDBFQUFXOzBCQUN6Qiw0RUFBQ2U7b0JBQUlDLFdBQVdoQiw4RUFBZTs7c0NBQzdCLDhEQUFDcUI7NEJBQUdMLFdBQVdoQiwrRUFBZ0I7c0NBQUdrQixNQUFNSyxLQUFLOzs7Ozs7c0NBQzdDLDhEQUFDQzs0QkFBRVIsV0FBV2hCLHFGQUFzQjtzQ0FBR2tCLE1BQU1RLFdBQVc7Ozs7OztzQ0FDeEQsOERBQUNDOzRCQUFLWCxXQUFXaEIsOEVBQWU7c0NBQUdrQixNQUFNVyxJQUFJOzs7Ozs7c0NBQzdDLDhEQUFDRjs0QkFBS1gsV0FBV2hCLDhFQUFlO3NDQUFHa0IsTUFBTVksUUFBUTs7Ozs7O3NDQUNqRCw4REFBQ0g7NEJBQUtYLFdBQVdoQiwwRUFBVztzQ0FBR2tCLE1BQU1hLElBQUk7Ozs7OztzQ0FDekMsOERBQUNKOzRCQUFLWCxXQUFXaEIsOEVBQWU7c0NBQUdrQixNQUFNYyxRQUFROzs7Ozs7Ozs7Ozs7ZUFQbkJkLE1BQU1MLEVBQUU7Ozs7Ozs7Ozs7QUFhbEQ7QUFFQSxpRUFBZVIsU0FBU0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL3BhZ2VzL2V2ZW50ZGV0YWlsLmpzPzRlMjAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi9zdHlsZXMvam9pbmV2ZW50Lm1vZHVsZS5jc3MnO1xyXG5pbXBvcnQge2RiLGRvYywgZ2V0RG9jcywgY29sbGVjdGlvbn0gZnJvbSAnL3BhZ2VzL2ZpcmViYXNlJ1xyXG5jb25zdCBzZWVkZXRhaWwgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2RldGFpbHMsIHNldERldGFpbHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBhc3luYyBmdW5jdGlvbiBmZXRjaEV2ZW50c0RhdGEoKSB7XHJcbiAgICAgIGNvbnN0IHF1ZXJ5U25hcHNob3QgPSBhd2FpdCBnZXREb2NzKGNvbGxlY3Rpb24oZGIsICdldmVudHMnKSk7XHJcbiAgICAgIGNvbnN0IGV2ZW50c0RhdGEgPSBxdWVyeVNuYXBzaG90LmRvY3MubWFwKChkb2MpID0+ICh7IGlkOiBkb2MuaWQsIC4uLmRvYy5kYXRhKCkgfSkpO1xyXG4gICAgICBzZXREZXRhaWxzKGV2ZW50c0RhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIGZldGNoRXZlbnRzRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jYXJkY29udGFpbmVyfT5cclxuICAgICAge2RldGFpbHMubWFwKChldmVudCkgPT4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY2FyZH0ga2V5PXtldmVudC5pZH0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNhcmRib2R5fT5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT17c3R5bGVzLmNhcmR0aXRsZX0+e2V2ZW50LnRpdGxlfTwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17c3R5bGVzLmNhcmRkaXNjcmlwdGlvbn0+e2V2ZW50LmRlc2NyaXB0aW9ufTwvcD5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtzdHlsZXMuY2FyZGRhdGV9PntldmVudC5kYXRlfTwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtzdHlsZXMubG9jYXRpb259PntldmVudC5sb2NhdGlvbn08L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17c3R5bGVzLnRpbWV9PntldmVudC50aW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtzdHlsZXMuaW52aXRlZXN9PntldmVudC5pbnZpdGVlc308L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgc2VlZGV0YWlsO1xyXG4iXSwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJzdHlsZXMiLCJkYiIsImRvYyIsImdldERvY3MiLCJjb2xsZWN0aW9uIiwic2VlZGV0YWlsIiwiZGV0YWlscyIsInNldERldGFpbHMiLCJmZXRjaEV2ZW50c0RhdGEiLCJxdWVyeVNuYXBzaG90IiwiZXZlbnRzRGF0YSIsImRvY3MiLCJtYXAiLCJpZCIsImRhdGEiLCJkaXYiLCJjbGFzc05hbWUiLCJjYXJkY29udGFpbmVyIiwiZXZlbnQiLCJjYXJkIiwiY2FyZGJvZHkiLCJoMiIsImNhcmR0aXRsZSIsInRpdGxlIiwicCIsImNhcmRkaXNjcmlwdGlvbiIsImRlc2NyaXB0aW9uIiwic3BhbiIsImNhcmRkYXRlIiwiZGF0ZSIsImxvY2F0aW9uIiwidGltZSIsImludml0ZWVzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/eventdetail.js\n");

/***/ }),

/***/ "./pages/firebase.js":
/*!***************************!*\
  !*** ./pages/firebase.js ***!
  \***************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"addDoc\": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.addDoc),\n/* harmony export */   \"auth\": () => (/* binding */ auth),\n/* harmony export */   \"collection\": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.collection),\n/* harmony export */   \"createUserWithEmailAndPassword\": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.createUserWithEmailAndPassword),\n/* harmony export */   \"db\": () => (/* binding */ db),\n/* harmony export */   \"doc\": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.doc),\n/* harmony export */   \"getDocs\": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.getDocs)\n/* harmony export */ });\n/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase/app */ \"firebase/app\");\n/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase/auth */ \"firebase/auth\");\n/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase/firestore */ \"firebase/firestore\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__]);\n([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\nconst firebaseConfig = {\n    apiKey: \"AIzaSyC8xZHU_-jM-F22bUNsgaxoTPuNqQ4BoAQ\",\n    authDomain: \"event-app-dd06a.firebaseapp.com\",\n    projectId: \"event-app-dd06a\",\n    storageBucket: \"event-app-dd06a.appspot.com\",\n    messagingSenderId: \"900405376318\",\n    appId: \"1:900405376318:web:f9298028479f66b166e86f\"\n};\nconst app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(firebaseConfig);\nconst auth = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__.getAuth)(app);\nconst db = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.getFirestore)(app);\n\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9maXJlYmFzZS5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQTZDO0FBQzJCO0FBQ1k7QUFDcEYsTUFBTVEsaUJBQWlCO0lBQ25CQyxRQUFRO0lBQ1JDLFlBQVk7SUFDWkMsV0FBVztJQUNYQyxlQUFlO0lBQ2ZDLG1CQUFtQjtJQUNuQkMsT0FBTztBQUNUO0FBQ0EsTUFBTUMsTUFBTWYsMkRBQWFBLENBQUNRO0FBQ25CLE1BQU1RLE9BQU9mLHNEQUFPQSxDQUFDYyxLQUFLO0FBQzFCLE1BQU1FLEtBQUtkLGdFQUFZQSxDQUFDWSxLQUFLO0FBQ3FDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXktYXBwLy4vcGFnZXMvZmlyZWJhc2UuanM/MzRjMCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBpbml0aWFsaXplQXBwIH0gZnJvbSBcImZpcmViYXNlL2FwcFwiO1xyXG5pbXBvcnQgeyBnZXRBdXRoLCBjcmVhdGVVc2VyV2l0aEVtYWlsQW5kUGFzc3dvcmQgfSBmcm9tIFwiZmlyZWJhc2UvYXV0aFwiO1xyXG5pbXBvcnQgeyBnZXRGaXJlc3RvcmUsIGNvbGxlY3Rpb24sIGFkZERvYywgZG9jLCBnZXREb2NzIH0gZnJvbSBcImZpcmViYXNlL2ZpcmVzdG9yZVwiO1xyXG5jb25zdCBmaXJlYmFzZUNvbmZpZyA9IHtcclxuICAgIGFwaUtleTogXCJBSXphU3lDOHhaSFVfLWpNLUYyMmJVTnNnYXhvVFB1TnFRNEJvQVFcIixcclxuICAgIGF1dGhEb21haW46IFwiZXZlbnQtYXBwLWRkMDZhLmZpcmViYXNlYXBwLmNvbVwiLFxyXG4gICAgcHJvamVjdElkOiBcImV2ZW50LWFwcC1kZDA2YVwiLFxyXG4gICAgc3RvcmFnZUJ1Y2tldDogXCJldmVudC1hcHAtZGQwNmEuYXBwc3BvdC5jb21cIixcclxuICAgIG1lc3NhZ2luZ1NlbmRlcklkOiBcIjkwMDQwNTM3NjMxOFwiLFxyXG4gICAgYXBwSWQ6IFwiMTo5MDA0MDUzNzYzMTg6d2ViOmY5Mjk4MDI4NDc5ZjY2YjE2NmU4NmZcIlxyXG4gIH07XHJcbiAgY29uc3QgYXBwID0gaW5pdGlhbGl6ZUFwcChmaXJlYmFzZUNvbmZpZyk7XHJcbiAgZXhwb3J0IGNvbnN0IGF1dGggPSBnZXRBdXRoKGFwcCk7XHJcbiAgZXhwb3J0IGNvbnN0IGRiID0gZ2V0RmlyZXN0b3JlKGFwcCk7XHJcbiAgZXhwb3J0IHtjcmVhdGVVc2VyV2l0aEVtYWlsQW5kUGFzc3dvcmQsIGNvbGxlY3Rpb24sIGFkZERvYywgZG9jLCBnZXREb2NzfSJdLCJuYW1lcyI6WyJpbml0aWFsaXplQXBwIiwiZ2V0QXV0aCIsImNyZWF0ZVVzZXJXaXRoRW1haWxBbmRQYXNzd29yZCIsImdldEZpcmVzdG9yZSIsImNvbGxlY3Rpb24iLCJhZGREb2MiLCJkb2MiLCJnZXREb2NzIiwiZmlyZWJhc2VDb25maWciLCJhcGlLZXkiLCJhdXRoRG9tYWluIiwicHJvamVjdElkIiwic3RvcmFnZUJ1Y2tldCIsIm1lc3NhZ2luZ1NlbmRlcklkIiwiYXBwSWQiLCJhcHAiLCJhdXRoIiwiZGIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/firebase.js\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "firebase/app":
/*!*******************************!*\
  !*** external "firebase/app" ***!
  \*******************************/
/***/ ((module) => {

"use strict";
module.exports = import("firebase/app");;

/***/ }),

/***/ "firebase/auth":
/*!********************************!*\
  !*** external "firebase/auth" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = import("firebase/auth");;

/***/ }),

/***/ "firebase/firestore":
/*!*************************************!*\
  !*** external "firebase/firestore" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = import("firebase/firestore");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/eventdetail.js"));
module.exports = __webpack_exports__;

})();