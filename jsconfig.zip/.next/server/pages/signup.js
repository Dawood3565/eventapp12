/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/signup";
exports.ids = ["pages/signup"];
exports.modules = {

/***/ "./styles/signup.module.css":
/*!**********************************!*\
  !*** ./styles/signup.module.css ***!
  \**********************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"logincontainer\": \"signup_logincontainer__mZZ8H\",\n\t\"h1\": \"signup_h1__oMpuv\",\n\t\"form\": \"signup_form__TRni4\",\n\t\"label\": \"signup_label__WNfsY\",\n\t\"input\": \"signup_input__DrhaQ\",\n\t\"button\": \"signup_button__OUmBm\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvc2lnbnVwLm1vZHVsZS5jc3MuanMiLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXktYXBwLy4vc3R5bGVzL3NpZ251cC5tb2R1bGUuY3NzP2U5NDIiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gRXhwb3J0c1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cdFwibG9naW5jb250YWluZXJcIjogXCJzaWdudXBfbG9naW5jb250YWluZXJfX21aWjhIXCIsXG5cdFwiaDFcIjogXCJzaWdudXBfaDFfX29NcHV2XCIsXG5cdFwiZm9ybVwiOiBcInNpZ251cF9mb3JtX19UUm5pNFwiLFxuXHRcImxhYmVsXCI6IFwic2lnbnVwX2xhYmVsX19XTmZzWVwiLFxuXHRcImlucHV0XCI6IFwic2lnbnVwX2lucHV0X19EcmhhUVwiLFxuXHRcImJ1dHRvblwiOiBcInNpZ251cF9idXR0b25fX09VbUJtXCJcbn07XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./styles/signup.module.css\n");

/***/ }),

/***/ "./pages/firebase.js":
/*!***************************!*\
  !*** ./pages/firebase.js ***!
  \***************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"addDoc\": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.addDoc),\n/* harmony export */   \"auth\": () => (/* binding */ auth),\n/* harmony export */   \"collection\": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.collection),\n/* harmony export */   \"createUserWithEmailAndPassword\": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.createUserWithEmailAndPassword),\n/* harmony export */   \"db\": () => (/* binding */ db),\n/* harmony export */   \"doc\": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.doc),\n/* harmony export */   \"getDocs\": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.getDocs)\n/* harmony export */ });\n/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase/app */ \"firebase/app\");\n/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase/auth */ \"firebase/auth\");\n/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase/firestore */ \"firebase/firestore\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__]);\n([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\nconst firebaseConfig = {\n    apiKey: \"AIzaSyC8xZHU_-jM-F22bUNsgaxoTPuNqQ4BoAQ\",\n    authDomain: \"event-app-dd06a.firebaseapp.com\",\n    projectId: \"event-app-dd06a\",\n    storageBucket: \"event-app-dd06a.appspot.com\",\n    messagingSenderId: \"900405376318\",\n    appId: \"1:900405376318:web:f9298028479f66b166e86f\"\n};\nconst app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(firebaseConfig);\nconst auth = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__.getAuth)(app);\nconst db = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.getFirestore)(app);\n\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9maXJlYmFzZS5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQTZDO0FBQzJCO0FBQ1k7QUFDcEYsTUFBTVEsaUJBQWlCO0lBQ25CQyxRQUFRO0lBQ1JDLFlBQVk7SUFDWkMsV0FBVztJQUNYQyxlQUFlO0lBQ2ZDLG1CQUFtQjtJQUNuQkMsT0FBTztBQUNUO0FBQ0EsTUFBTUMsTUFBTWYsMkRBQWFBLENBQUNRO0FBQ25CLE1BQU1RLE9BQU9mLHNEQUFPQSxDQUFDYyxLQUFLO0FBQzFCLE1BQU1FLEtBQUtkLGdFQUFZQSxDQUFDWSxLQUFLO0FBQ3FDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXktYXBwLy4vcGFnZXMvZmlyZWJhc2UuanM/MzRjMCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBpbml0aWFsaXplQXBwIH0gZnJvbSBcImZpcmViYXNlL2FwcFwiO1xyXG5pbXBvcnQgeyBnZXRBdXRoLCBjcmVhdGVVc2VyV2l0aEVtYWlsQW5kUGFzc3dvcmQgfSBmcm9tIFwiZmlyZWJhc2UvYXV0aFwiO1xyXG5pbXBvcnQgeyBnZXRGaXJlc3RvcmUsIGNvbGxlY3Rpb24sIGFkZERvYywgZG9jLCBnZXREb2NzIH0gZnJvbSBcImZpcmViYXNlL2ZpcmVzdG9yZVwiO1xyXG5jb25zdCBmaXJlYmFzZUNvbmZpZyA9IHtcclxuICAgIGFwaUtleTogXCJBSXphU3lDOHhaSFVfLWpNLUYyMmJVTnNnYXhvVFB1TnFRNEJvQVFcIixcclxuICAgIGF1dGhEb21haW46IFwiZXZlbnQtYXBwLWRkMDZhLmZpcmViYXNlYXBwLmNvbVwiLFxyXG4gICAgcHJvamVjdElkOiBcImV2ZW50LWFwcC1kZDA2YVwiLFxyXG4gICAgc3RvcmFnZUJ1Y2tldDogXCJldmVudC1hcHAtZGQwNmEuYXBwc3BvdC5jb21cIixcclxuICAgIG1lc3NhZ2luZ1NlbmRlcklkOiBcIjkwMDQwNTM3NjMxOFwiLFxyXG4gICAgYXBwSWQ6IFwiMTo5MDA0MDUzNzYzMTg6d2ViOmY5Mjk4MDI4NDc5ZjY2YjE2NmU4NmZcIlxyXG4gIH07XHJcbiAgY29uc3QgYXBwID0gaW5pdGlhbGl6ZUFwcChmaXJlYmFzZUNvbmZpZyk7XHJcbiAgZXhwb3J0IGNvbnN0IGF1dGggPSBnZXRBdXRoKGFwcCk7XHJcbiAgZXhwb3J0IGNvbnN0IGRiID0gZ2V0RmlyZXN0b3JlKGFwcCk7XHJcbiAgZXhwb3J0IHtjcmVhdGVVc2VyV2l0aEVtYWlsQW5kUGFzc3dvcmQsIGNvbGxlY3Rpb24sIGFkZERvYywgZG9jLCBnZXREb2NzfSJdLCJuYW1lcyI6WyJpbml0aWFsaXplQXBwIiwiZ2V0QXV0aCIsImNyZWF0ZVVzZXJXaXRoRW1haWxBbmRQYXNzd29yZCIsImdldEZpcmVzdG9yZSIsImNvbGxlY3Rpb24iLCJhZGREb2MiLCJkb2MiLCJnZXREb2NzIiwiZmlyZWJhc2VDb25maWciLCJhcGlLZXkiLCJhdXRoRG9tYWluIiwicHJvamVjdElkIiwic3RvcmFnZUJ1Y2tldCIsIm1lc3NhZ2luZ1NlbmRlcklkIiwiYXBwSWQiLCJhcHAiLCJhdXRoIiwiZGIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/firebase.js\n");

/***/ }),

/***/ "./pages/signup.js":
/*!*************************!*\
  !*** ./pages/signup.js ***!
  \*************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _styles_signup_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../styles/signup.module.css */ \"./styles/signup.module.css\");\n/* harmony import */ var _styles_signup_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_signup_module_css__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _pages_firebase__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../pages/firebase */ \"./pages/firebase.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_firebase__WEBPACK_IMPORTED_MODULE_3__]);\n_pages_firebase__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\n//import { createUserWithEmailAndPassword} from 'firebase/auth'\nconst signup = ()=>{\n    const [Email, setEmail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const [Password, setPassword] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const handleSubmit = async (event)=>{\n        event.preventDefault();\n        try {\n            // const result = await createUserWithEmailAndPassword(auth, Email, Password)\n            // alert(result);\n            // setEmail('')\n            // setPassword('')\n            console.log(Email);\n            console.log(Password);\n            // Create a new user with the email and password\n            // If successful, redirect the user to the login page\n            router.push(\"/login\");\n        } catch (error) {\n            // If there's an error, display it to the user\n            alert(\"error\");\n        }\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: (_styles_signup_module_css__WEBPACK_IMPORTED_MODULE_4___default().logincontainer),\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                    className: (_styles_signup_module_css__WEBPACK_IMPORTED_MODULE_4___default().h1),\n                    children: \"Sign Up\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\signup.js\",\n                    lineNumber: 36,\n                    columnNumber: 9\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"form\", {\n                    className: (_styles_signup_module_css__WEBPACK_IMPORTED_MODULE_4___default().form),\n                    onSubmit: handleSubmit,\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"label\", {\n                            className: (_styles_signup_module_css__WEBPACK_IMPORTED_MODULE_4___default().label),\n                            children: [\n                                \"Email:\",\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                                    className: (_styles_signup_module_css__WEBPACK_IMPORTED_MODULE_4___default().input),\n                                    type: \"email\",\n                                    value: Email,\n                                    onChange: (e)=>setEmail(e.target.value)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\signup.js\",\n                                    lineNumber: 40,\n                                    columnNumber: 13\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\signup.js\",\n                            lineNumber: 38,\n                            columnNumber: 11\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\signup.js\",\n                            lineNumber: 47,\n                            columnNumber: 11\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"label\", {\n                            children: [\n                                \"Password:\",\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                                    className: (_styles_signup_module_css__WEBPACK_IMPORTED_MODULE_4___default().input),\n                                    type: \"password\",\n                                    value: Password,\n                                    onChange: (e)=>setPassword(e.target.value)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\signup.js\",\n                                    lineNumber: 50,\n                                    columnNumber: 13\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\signup.js\",\n                            lineNumber: 48,\n                            columnNumber: 11\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\signup.js\",\n                            lineNumber: 57,\n                            columnNumber: 11\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                            className: (_styles_signup_module_css__WEBPACK_IMPORTED_MODULE_4___default().button),\n                            type: \"submit\",\n                            children: \"Signup\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\signup.js\",\n                            lineNumber: 58,\n                            columnNumber: 11\n                        }, undefined)\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\signup.js\",\n                    lineNumber: 37,\n                    columnNumber: 9\n                }, undefined)\n            ]\n        }, void 0, true, {\n            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\signup.js\",\n            lineNumber: 35,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\signup.js\",\n        lineNumber: 34,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (signup);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9zaWdudXAuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBZ0M7QUFDTztBQUNTO0FBQ3NCO0FBQ3RFLCtEQUErRDtBQUUvRCxNQUFNSyxTQUFTLElBQU07SUFDbkIsTUFBTSxDQUFDQyxPQUFPQyxTQUFTLEdBQUdQLCtDQUFRQSxDQUFDO0lBQ25DLE1BQU0sQ0FBQ1EsVUFBVUMsWUFBWSxHQUFHVCwrQ0FBUUEsQ0FBQztJQUN6QyxNQUFNLENBQUNVLE9BQU9DLFNBQVMsR0FBR1gsK0NBQVFBLENBQUMsSUFBSTtJQUN2QyxNQUFNWSxTQUFTWCxzREFBU0E7SUFFeEIsTUFBTVksZUFBZSxPQUFNQyxRQUFVO1FBQ25DQSxNQUFNQyxjQUFjO1FBQ3BCLElBQUk7WUFDQSw2RUFBNkU7WUFDN0UsaUJBQWlCO1lBQ2pCLGVBQWU7WUFDZixrQkFBa0I7WUFDbEJDLFFBQVFDLEdBQUcsQ0FBQ1g7WUFDWlUsUUFBUUMsR0FBRyxDQUFDVDtZQUNaLGdEQUFnRDtZQUVwRCxxREFBcUQ7WUFDckRJLE9BQU9NLElBQUksQ0FBQztRQUNWLEVBQUUsT0FBT1IsT0FBTztZQUNkLDhDQUE4QztZQUM3Q1MsTUFBTTtRQUNUO0lBRUo7SUFFQSxxQkFDRSw4REFBQ0M7a0JBQ0MsNEVBQUNBO1lBQUlDLFdBQVduQixpRkFBcUI7OzhCQUNuQyw4REFBQ3FCO29CQUFHRixXQUFXbkIscUVBQVM7OEJBQUU7Ozs7Ozs4QkFDMUIsOERBQUNzQjtvQkFBS0gsV0FBV25CLHVFQUFXO29CQUFFdUIsVUFBVVo7O3NDQUN0Qyw4REFBQ2E7NEJBQU1MLFdBQVduQix3RUFBWTs7Z0NBQUU7OENBRTlCLDhEQUFDeUI7b0NBQ0NOLFdBQVduQix3RUFBWTtvQ0FDdkIwQixNQUFLO29DQUNMQyxPQUFPdkI7b0NBQ1B3QixVQUFVLENBQUNDLElBQU14QixTQUFTd0IsRUFBRUMsTUFBTSxDQUFDSCxLQUFLOzs7Ozs7Ozs7Ozs7c0NBRzVDLDhEQUFDSTs7Ozs7c0NBQ0QsOERBQUNQOztnQ0FBTTs4Q0FFTCw4REFBQ0M7b0NBQ0NOLFdBQVduQix3RUFBWTtvQ0FDdkIwQixNQUFLO29DQUNMQyxPQUFPckI7b0NBQ1BzQixVQUFVLENBQUNDLElBQU10QixZQUFZc0IsRUFBRUMsTUFBTSxDQUFDSCxLQUFLOzs7Ozs7Ozs7Ozs7c0NBRy9DLDhEQUFDSTs7Ozs7c0NBQ0QsOERBQUNDOzRCQUFPYixXQUFXbkIseUVBQWE7NEJBQUUwQixNQUFLO3NDQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQU8xRDtBQUVBLGlFQUFldkIsTUFBTUEsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL3BhZ2VzL3NpZ251cC5qcz9jYThjIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJ1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uL3N0eWxlcy9zaWdudXAubW9kdWxlLmNzcydcclxuaW1wb3J0IHsgYXV0aCwgY3JlYXRlVXNlcldpdGhFbWFpbEFuZFBhc3N3b3JkIH0gZnJvbSAnL3BhZ2VzL2ZpcmViYXNlJ1xyXG4vL2ltcG9ydCB7IGNyZWF0ZVVzZXJXaXRoRW1haWxBbmRQYXNzd29yZH0gZnJvbSAnZmlyZWJhc2UvYXV0aCdcclxuXHJcbmNvbnN0IHNpZ251cCA9ICgpID0+IHtcclxuICBjb25zdCBbRW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtQYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShudWxsKVxyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jKGV2ZW50KSA9PiB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICB0cnkge1xyXG4gICAgICAgIC8vIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNyZWF0ZVVzZXJXaXRoRW1haWxBbmRQYXNzd29yZChhdXRoLCBFbWFpbCwgUGFzc3dvcmQpXHJcbiAgICAgICAgLy8gYWxlcnQocmVzdWx0KTtcclxuICAgICAgICAvLyBzZXRFbWFpbCgnJylcclxuICAgICAgICAvLyBzZXRQYXNzd29yZCgnJylcclxuICAgICAgICBjb25zb2xlLmxvZyhFbWFpbCk7XHJcbiAgICAgICAgY29uc29sZS5sb2coUGFzc3dvcmQpO1xyXG4gICAgICAgIC8vIENyZWF0ZSBhIG5ldyB1c2VyIHdpdGggdGhlIGVtYWlsIGFuZCBwYXNzd29yZFxyXG5cclxuICAgIC8vIElmIHN1Y2Nlc3NmdWwsIHJlZGlyZWN0IHRoZSB1c2VyIHRvIHRoZSBsb2dpbiBwYWdlXHJcbiAgICByb3V0ZXIucHVzaCgnL2xvZ2luJylcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAvLyBJZiB0aGVyZSdzIGFuIGVycm9yLCBkaXNwbGF5IGl0IHRvIHRoZSB1c2VyXHJcbiAgICAgICAgIGFsZXJ0KCdlcnJvcicpO1xyXG4gICAgICB9XHJcbiAgIFxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubG9naW5jb250YWluZXJ9PlxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9e3N0eWxlcy5oMX0+U2lnbiBVcDwvaDE+XHJcbiAgICAgICAgPGZvcm0gY2xhc3NOYW1lPXtzdHlsZXMuZm9ybX0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPXtzdHlsZXMubGFiZWx9PlxyXG4gICAgICAgICAgICBFbWFpbDpcclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMuaW5wdXR9XHJcbiAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17RW1haWx9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICA8bGFiZWw+XHJcbiAgICAgICAgICAgIFBhc3N3b3JkOlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5pbnB1dH1cclxuICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtQYXNzd29yZH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPXtzdHlsZXMuYnV0dG9ufSB0eXBlPVwic3VibWl0XCI+XHJcbiAgICAgICAgICAgIFNpZ251cFxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgc2lnbnVwXHJcbiJdLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZVJvdXRlciIsInN0eWxlcyIsImF1dGgiLCJjcmVhdGVVc2VyV2l0aEVtYWlsQW5kUGFzc3dvcmQiLCJzaWdudXAiLCJFbWFpbCIsInNldEVtYWlsIiwiUGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImVycm9yIiwic2V0RXJyb3IiLCJyb3V0ZXIiLCJoYW5kbGVTdWJtaXQiLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwiY29uc29sZSIsImxvZyIsInB1c2giLCJhbGVydCIsImRpdiIsImNsYXNzTmFtZSIsImxvZ2luY29udGFpbmVyIiwiaDEiLCJmb3JtIiwib25TdWJtaXQiLCJsYWJlbCIsImlucHV0IiwidHlwZSIsInZhbHVlIiwib25DaGFuZ2UiLCJlIiwidGFyZ2V0IiwiYnIiLCJidXR0b24iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/signup.js\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "firebase/app":
/*!*******************************!*\
  !*** external "firebase/app" ***!
  \*******************************/
/***/ ((module) => {

"use strict";
module.exports = import("firebase/app");;

/***/ }),

/***/ "firebase/auth":
/*!********************************!*\
  !*** external "firebase/auth" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = import("firebase/auth");;

/***/ }),

/***/ "firebase/firestore":
/*!*************************************!*\
  !*** external "firebase/firestore" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = import("firebase/firestore");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/signup.js"));
module.exports = __webpack_exports__;

})();