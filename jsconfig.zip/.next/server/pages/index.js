/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./styles/Home.module.css":
/*!********************************!*\
  !*** ./styles/Home.module.css ***!
  \********************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"cardcontainer\": \"Home_cardcontainer__Fe4oT\",\n\t\"card\": \"Home_card___LpL1\",\n\t\"cardTitle\": \"Home_cardTitle__1mj3t\",\n\t\"cardDescription\": \"Home_cardDescription__iWMlk\",\n\t\"cardDate\": \"Home_cardDate__hgeQm\",\n\t\"btnview\": \"Home_btnview__r3lRx\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzLmpzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL3N0eWxlcy9Ib21lLm1vZHVsZS5jc3M/YzRmNyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBFeHBvcnRzXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0XCJjYXJkY29udGFpbmVyXCI6IFwiSG9tZV9jYXJkY29udGFpbmVyX19GZTRvVFwiLFxuXHRcImNhcmRcIjogXCJIb21lX2NhcmRfX19McEwxXCIsXG5cdFwiY2FyZFRpdGxlXCI6IFwiSG9tZV9jYXJkVGl0bGVfXzFtajN0XCIsXG5cdFwiY2FyZERlc2NyaXB0aW9uXCI6IFwiSG9tZV9jYXJkRGVzY3JpcHRpb25fX2lXTWxrXCIsXG5cdFwiY2FyZERhdGVcIjogXCJIb21lX2NhcmREYXRlX19oZ2VRbVwiLFxuXHRcImJ0bnZpZXdcIjogXCJIb21lX2J0bnZpZXdfX3IzbFJ4XCJcbn07XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./styles/Home.module.css\n");

/***/ }),

/***/ "./pages/firebase.js":
/*!***************************!*\
  !*** ./pages/firebase.js ***!
  \***************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"addDoc\": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.addDoc),\n/* harmony export */   \"auth\": () => (/* binding */ auth),\n/* harmony export */   \"collection\": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.collection),\n/* harmony export */   \"createUserWithEmailAndPassword\": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.createUserWithEmailAndPassword),\n/* harmony export */   \"db\": () => (/* binding */ db),\n/* harmony export */   \"doc\": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.doc),\n/* harmony export */   \"getDocs\": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.getDocs)\n/* harmony export */ });\n/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase/app */ \"firebase/app\");\n/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase/auth */ \"firebase/auth\");\n/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase/firestore */ \"firebase/firestore\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__]);\n([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\nconst firebaseConfig = {\n    apiKey: \"AIzaSyC8xZHU_-jM-F22bUNsgaxoTPuNqQ4BoAQ\",\n    authDomain: \"event-app-dd06a.firebaseapp.com\",\n    projectId: \"event-app-dd06a\",\n    storageBucket: \"event-app-dd06a.appspot.com\",\n    messagingSenderId: \"900405376318\",\n    appId: \"1:900405376318:web:f9298028479f66b166e86f\"\n};\nconst app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(firebaseConfig);\nconst auth = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__.getAuth)(app);\nconst db = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.getFirestore)(app);\n\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9maXJlYmFzZS5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQTZDO0FBQzJCO0FBQ1k7QUFDcEYsTUFBTVEsaUJBQWlCO0lBQ25CQyxRQUFRO0lBQ1JDLFlBQVk7SUFDWkMsV0FBVztJQUNYQyxlQUFlO0lBQ2ZDLG1CQUFtQjtJQUNuQkMsT0FBTztBQUNUO0FBQ0EsTUFBTUMsTUFBTWYsMkRBQWFBLENBQUNRO0FBQ25CLE1BQU1RLE9BQU9mLHNEQUFPQSxDQUFDYyxLQUFLO0FBQzFCLE1BQU1FLEtBQUtkLGdFQUFZQSxDQUFDWSxLQUFLO0FBQ3FDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXktYXBwLy4vcGFnZXMvZmlyZWJhc2UuanM/MzRjMCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBpbml0aWFsaXplQXBwIH0gZnJvbSBcImZpcmViYXNlL2FwcFwiO1xyXG5pbXBvcnQgeyBnZXRBdXRoLCBjcmVhdGVVc2VyV2l0aEVtYWlsQW5kUGFzc3dvcmQgfSBmcm9tIFwiZmlyZWJhc2UvYXV0aFwiO1xyXG5pbXBvcnQgeyBnZXRGaXJlc3RvcmUsIGNvbGxlY3Rpb24sIGFkZERvYywgZG9jLCBnZXREb2NzIH0gZnJvbSBcImZpcmViYXNlL2ZpcmVzdG9yZVwiO1xyXG5jb25zdCBmaXJlYmFzZUNvbmZpZyA9IHtcclxuICAgIGFwaUtleTogXCJBSXphU3lDOHhaSFVfLWpNLUYyMmJVTnNnYXhvVFB1TnFRNEJvQVFcIixcclxuICAgIGF1dGhEb21haW46IFwiZXZlbnQtYXBwLWRkMDZhLmZpcmViYXNlYXBwLmNvbVwiLFxyXG4gICAgcHJvamVjdElkOiBcImV2ZW50LWFwcC1kZDA2YVwiLFxyXG4gICAgc3RvcmFnZUJ1Y2tldDogXCJldmVudC1hcHAtZGQwNmEuYXBwc3BvdC5jb21cIixcclxuICAgIG1lc3NhZ2luZ1NlbmRlcklkOiBcIjkwMDQwNTM3NjMxOFwiLFxyXG4gICAgYXBwSWQ6IFwiMTo5MDA0MDUzNzYzMTg6d2ViOmY5Mjk4MDI4NDc5ZjY2YjE2NmU4NmZcIlxyXG4gIH07XHJcbiAgY29uc3QgYXBwID0gaW5pdGlhbGl6ZUFwcChmaXJlYmFzZUNvbmZpZyk7XHJcbiAgZXhwb3J0IGNvbnN0IGF1dGggPSBnZXRBdXRoKGFwcCk7XHJcbiAgZXhwb3J0IGNvbnN0IGRiID0gZ2V0RmlyZXN0b3JlKGFwcCk7XHJcbiAgZXhwb3J0IHtjcmVhdGVVc2VyV2l0aEVtYWlsQW5kUGFzc3dvcmQsIGNvbGxlY3Rpb24sIGFkZERvYywgZG9jLCBnZXREb2NzfSJdLCJuYW1lcyI6WyJpbml0aWFsaXplQXBwIiwiZ2V0QXV0aCIsImNyZWF0ZVVzZXJXaXRoRW1haWxBbmRQYXNzd29yZCIsImdldEZpcmVzdG9yZSIsImNvbGxlY3Rpb24iLCJhZGREb2MiLCJkb2MiLCJnZXREb2NzIiwiZmlyZWJhc2VDb25maWciLCJhcGlLZXkiLCJhdXRoRG9tYWluIiwicHJvamVjdElkIiwic3RvcmFnZUJ1Y2tldCIsIm1lc3NhZ2luZ1NlbmRlcklkIiwiYXBwSWQiLCJhcHAiLCJhdXRoIiwiZGIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/firebase.js\n");

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _pages_firebase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../pages/firebase */ \"./pages/firebase.js\");\n/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../styles/Home.module.css */ \"./styles/Home.module.css\");\n/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_firebase__WEBPACK_IMPORTED_MODULE_2__]);\n_pages_firebase__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n//import Image from 'next/image'\n//import { Inter } from 'next/font/google'\n\n\n\n\nfunction Home() {\n    const [events, setEvents] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();\n    // useEffect(()=>{\n    //   const docRef = collection(db, \"events\");\n    //    const snapshots =  getDocs(docRef)\n    //    const docs = snapshots.docs.map((doc) =>doc.data())\n    //    console.log(snapshots);\n    //    console.log(docs);\n    //  },[])\n    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{\n        async function fetchEventsData() {\n            const querySnapshot = await (0,_pages_firebase__WEBPACK_IMPORTED_MODULE_2__.getDocs)((0,_pages_firebase__WEBPACK_IMPORTED_MODULE_2__.collection)(_pages_firebase__WEBPACK_IMPORTED_MODULE_2__.db, \"events\"));\n            const eventsData = querySnapshot.docs.map((doc)=>({\n                    id: doc.id,\n                    ...doc.data()\n                }));\n            setEvents(eventsData);\n        }\n        fetchEventsData();\n    }, []);\n    const handleJoin = (e)=>{\n        e.preventDefault();\n        alert(\"join successful\");\n    //router.push('/joinevent');\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"title\", {\n                        children: \"Create Next App\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\index.js\",\n                        lineNumber: 37,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"meta\", {\n                        name: \"description\",\n                        content: \"Generated by create next app\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\index.js\",\n                        lineNumber: 38,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"meta\", {\n                        name: \"viewport\",\n                        content: \"width=device-width, initial-scale=1\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\index.js\",\n                        lineNumber: 39,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"link\", {\n                        rel: \"icon\",\n                        href: \"/favicon.ico\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\index.js\",\n                        lineNumber: 40,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\index.js\",\n                lineNumber: 36,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                children: \"Events\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\index.js\",\n                lineNumber: 43,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().cardcontainer),\n                children: events.map((event)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().card),\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().cardbody),\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h2\", {\n                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().cardtitle),\n                                    children: event.title\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\index.js\",\n                                    lineNumber: 48,\n                                    columnNumber: 11\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().carddiscription),\n                                    children: event.description\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\index.js\",\n                                    lineNumber: 49,\n                                    columnNumber: 11\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().carddate),\n                                    children: `date: ${event.date}`\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\index.js\",\n                                    lineNumber: 50,\n                                    columnNumber: 11\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                                    onClick: handleJoin,\n                                    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().btnview),\n                                    children: \"Join\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\index.js\",\n                                    lineNumber: 51,\n                                    columnNumber: 11\n                                }, this)\n                            ]\n                        }, event.id, true, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\index.js\",\n                            lineNumber: 47,\n                            columnNumber: 9\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\index.js\",\n                        lineNumber: 46,\n                        columnNumber: 9\n                    }, this))\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\index.js\",\n                lineNumber: 44,\n                columnNumber: 9\n            }, this)\n        ]\n    }, void 0, true);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQTRCO0FBQzVCLGdDQUFnQztBQUNoQywwQ0FBMEM7QUFDaUI7QUFDYjtBQUNMO0FBQ0Y7QUFDeEIsU0FBU1MsT0FBTztJQUM3QixNQUFNLENBQUNDLFFBQVFDLFVBQVUsR0FBR0osK0NBQVFBLENBQUMsRUFBRTtJQUN2QyxNQUFNSyxTQUFTSixzREFBU0E7SUFDeEIsa0JBQWtCO0lBQ2xCLDZDQUE2QztJQUM3Qyx3Q0FBd0M7SUFDeEMseURBQXlEO0lBQ3pELDZCQUE2QjtJQUM3Qix3QkFBd0I7SUFDeEIsU0FBUztJQUNURixnREFBU0EsQ0FBQyxJQUFNO1FBQ2QsZUFBZU8sa0JBQWtCO1lBQy9CLE1BQU1DLGdCQUFnQixNQUFNWCx3REFBT0EsQ0FBQ0MsMkRBQVVBLENBQUNILCtDQUFFQSxFQUFFO1lBQ25ELE1BQU1jLGFBQWFELGNBQWNFLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUNmLE1BQVM7b0JBQUVnQixJQUFJaEIsSUFBSWdCLEVBQUU7b0JBQUUsR0FBR2hCLElBQUlpQixJQUFJLEVBQUU7Z0JBQUM7WUFDaEZSLFVBQVVJO1FBQ1o7UUFFQUY7SUFDRixHQUFHLEVBQUU7SUFFTCxNQUFNTyxhQUFhLENBQUNDLElBQU07UUFDeEJBLEVBQUVDLGNBQWM7UUFDaEJDLE1BQU07SUFDTiw0QkFBNEI7SUFDOUI7SUFFQSxxQkFDRTs7MEJBQ0UsOERBQUN2QixrREFBSUE7O2tDQUNILDhEQUFDd0I7a0NBQU07Ozs7OztrQ0FDUCw4REFBQ0M7d0JBQUtDLE1BQUs7d0JBQWNDLFNBQVE7Ozs7OztrQ0FDakMsOERBQUNGO3dCQUFLQyxNQUFLO3dCQUFXQyxTQUFROzs7Ozs7a0NBQzlCLDhEQUFDQzt3QkFBS0MsS0FBSTt3QkFBT0MsTUFBSzs7Ozs7Ozs7Ozs7OzBCQUd0Qiw4REFBQ0M7MEJBQUc7Ozs7OzswQkFDSiw4REFBQ0M7Z0JBQUlDLFdBQVc1Qiw4RUFBb0I7MEJBQ3JDSyxPQUFPTyxHQUFHLENBQUMsQ0FBQ2tCLHNCQUNYLDhEQUFDSDt3QkFBSUMsV0FBVzVCLHFFQUFXO2tDQUMzQiw0RUFBQzJCOzRCQUFJQyxXQUFXNUIseUVBQWU7OzhDQUM3Qiw4REFBQ2lDO29DQUFHTCxXQUFXNUIsMEVBQWdCOzhDQUFHOEIsTUFBTVgsS0FBSzs7Ozs7OzhDQUM3Qyw4REFBQ2dCO29DQUFFUCxXQUFXNUIsZ0ZBQXNCOzhDQUFHOEIsTUFBTU8sV0FBVzs7Ozs7OzhDQUN4RCw4REFBQ0M7b0NBQUtWLFdBQVc1Qix5RUFBZTs4Q0FBRyxDQUFDLE1BQU0sRUFBRThCLE1BQU1VLElBQUksQ0FBQyxDQUFDOzs7Ozs7OENBQ3hELDhEQUFDQztvQ0FBT0MsU0FBUzNCO29DQUFZYSxXQUFXNUIsd0VBQWM7OENBQUU7Ozs7Ozs7MkJBSnBCOEIsTUFBTWpCLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBWXRELENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9wYWdlcy9pbmRleC5qcz9iZWU3Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCdcbi8vaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnXG4vL2ltcG9ydCB7IEludGVyIH0gZnJvbSAnbmV4dC9mb250L2dvb2dsZSdcbmltcG9ydCB7ZGIsZG9jLCBnZXREb2NzLCBjb2xsZWN0aW9ufSBmcm9tICcvcGFnZXMvZmlyZWJhc2UnXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uL3N0eWxlcy9Ib21lLm1vZHVsZS5jc3MnXG5pbXBvcnQge3VzZUVmZmVjdCwgdXNlU3RhdGV9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKCkge1xuICBjb25zdCBbZXZlbnRzLCBzZXRFdmVudHNdID0gdXNlU3RhdGUoW10pO1xuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxuICAvLyB1c2VFZmZlY3QoKCk9PntcbiAgLy8gICBjb25zdCBkb2NSZWYgPSBjb2xsZWN0aW9uKGRiLCBcImV2ZW50c1wiKTtcbiAgLy8gICAgY29uc3Qgc25hcHNob3RzID0gIGdldERvY3MoZG9jUmVmKVxuICAvLyAgICBjb25zdCBkb2NzID0gc25hcHNob3RzLmRvY3MubWFwKChkb2MpID0+ZG9jLmRhdGEoKSlcbiAgLy8gICAgY29uc29sZS5sb2coc25hcHNob3RzKTtcbiAgLy8gICAgY29uc29sZS5sb2coZG9jcyk7XG4gIC8vICB9LFtdKVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGFzeW5jIGZ1bmN0aW9uIGZldGNoRXZlbnRzRGF0YSgpIHtcbiAgICAgIGNvbnN0IHF1ZXJ5U25hcHNob3QgPSBhd2FpdCBnZXREb2NzKGNvbGxlY3Rpb24oZGIsICdldmVudHMnKSk7XG4gICAgICBjb25zdCBldmVudHNEYXRhID0gcXVlcnlTbmFwc2hvdC5kb2NzLm1hcCgoZG9jKSA9PiAoeyBpZDogZG9jLmlkLCAuLi5kb2MuZGF0YSgpIH0pKTtcbiAgICAgIHNldEV2ZW50cyhldmVudHNEYXRhKTtcbiAgICB9XG5cbiAgICBmZXRjaEV2ZW50c0RhdGEoKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGhhbmRsZUpvaW4gPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBhbGVydCgnam9pbiBzdWNjZXNzZnVsJylcbiAgICAvL3JvdXRlci5wdXNoKCcvam9pbmV2ZW50Jyk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPkNyZWF0ZSBOZXh0IEFwcDwvdGl0bGU+XG4gICAgICAgIDxtZXRhIG5hbWU9XCJkZXNjcmlwdGlvblwiIGNvbnRlbnQ9XCJHZW5lcmF0ZWQgYnkgY3JlYXRlIG5leHQgYXBwXCIgLz5cbiAgICAgICAgPG1ldGEgbmFtZT1cInZpZXdwb3J0XCIgY29udGVudD1cIndpZHRoPWRldmljZS13aWR0aCwgaW5pdGlhbC1zY2FsZT0xXCIgLz5cbiAgICAgICAgPGxpbmsgcmVsPVwiaWNvblwiIGhyZWY9XCIvZmF2aWNvbi5pY29cIiAvPlxuICAgICAgPC9IZWFkPlxuICAgICAgXG4gICAgICAgIDxoMT5FdmVudHM8L2gxPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNhcmRjb250YWluZXJ9PlxuICAgICAge2V2ZW50cy5tYXAoKGV2ZW50KSA9PiAoIFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNhcmR9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNhcmRib2R5fSBrZXk9e2V2ZW50LmlkfT5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPXtzdHlsZXMuY2FyZHRpdGxlfT57ZXZlbnQudGl0bGV9PC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9e3N0eWxlcy5jYXJkZGlzY3JpcHRpb259PntldmVudC5kZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtzdHlsZXMuY2FyZGRhdGV9PntgZGF0ZTogJHtldmVudC5kYXRlfWB9PC9zcGFuPlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlSm9pbn0gY2xhc3NOYW1lPXtzdHlsZXMuYnRudmlld30+Sm9pbjwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApKX1cbiAgICA8L2Rpdj5cbiAgICAgIFxuICAgIDwvPlxuICApXG59XG4iXSwibmFtZXMiOlsiSGVhZCIsImRiIiwiZG9jIiwiZ2V0RG9jcyIsImNvbGxlY3Rpb24iLCJzdHlsZXMiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZVJvdXRlciIsIkhvbWUiLCJldmVudHMiLCJzZXRFdmVudHMiLCJyb3V0ZXIiLCJmZXRjaEV2ZW50c0RhdGEiLCJxdWVyeVNuYXBzaG90IiwiZXZlbnRzRGF0YSIsImRvY3MiLCJtYXAiLCJpZCIsImRhdGEiLCJoYW5kbGVKb2luIiwiZSIsInByZXZlbnREZWZhdWx0IiwiYWxlcnQiLCJ0aXRsZSIsIm1ldGEiLCJuYW1lIiwiY29udGVudCIsImxpbmsiLCJyZWwiLCJocmVmIiwiaDEiLCJkaXYiLCJjbGFzc05hbWUiLCJjYXJkY29udGFpbmVyIiwiZXZlbnQiLCJjYXJkIiwiY2FyZGJvZHkiLCJoMiIsImNhcmR0aXRsZSIsInAiLCJjYXJkZGlzY3JpcHRpb24iLCJkZXNjcmlwdGlvbiIsInNwYW4iLCJjYXJkZGF0ZSIsImRhdGUiLCJidXR0b24iLCJvbkNsaWNrIiwiYnRudmlldyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/index.js\n");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "firebase/app":
/*!*******************************!*\
  !*** external "firebase/app" ***!
  \*******************************/
/***/ ((module) => {

"use strict";
module.exports = import("firebase/app");;

/***/ }),

/***/ "firebase/auth":
/*!********************************!*\
  !*** external "firebase/auth" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = import("firebase/auth");;

/***/ }),

/***/ "firebase/firestore":
/*!*************************************!*\
  !*** external "firebase/firestore" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = import("firebase/firestore");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.js"));
module.exports = __webpack_exports__;

})();