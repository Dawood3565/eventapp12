/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/login";
exports.ids = ["pages/login"];
exports.modules = {

/***/ "./styles/login.module.css":
/*!*********************************!*\
  !*** ./styles/login.module.css ***!
  \*********************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"logincontainer\": \"login_logincontainer__mS_4u\",\n\t\"h1\": \"login_h1__YNjdY\",\n\t\"form\": \"login_form__H7Yjv\",\n\t\"label\": \"login_label__8GByl\",\n\t\"input\": \"login_input__eHZjI\",\n\t\"button\": \"login_button__fDcxV\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvbG9naW4ubW9kdWxlLmNzcy5qcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9zdHlsZXMvbG9naW4ubW9kdWxlLmNzcz80NTY1Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcImxvZ2luY29udGFpbmVyXCI6IFwibG9naW5fbG9naW5jb250YWluZXJfX21TXzR1XCIsXG5cdFwiaDFcIjogXCJsb2dpbl9oMV9fWU5qZFlcIixcblx0XCJmb3JtXCI6IFwibG9naW5fZm9ybV9fSDdZanZcIixcblx0XCJsYWJlbFwiOiBcImxvZ2luX2xhYmVsX184R0J5bFwiLFxuXHRcImlucHV0XCI6IFwibG9naW5faW5wdXRfX2VIWmpJXCIsXG5cdFwiYnV0dG9uXCI6IFwibG9naW5fYnV0dG9uX19mRGN4VlwiXG59O1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./styles/login.module.css\n");

/***/ }),

/***/ "./pages/login.js":
/*!************************!*\
  !*** ./pages/login.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _styles_login_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../styles/login.module.css */ \"./styles/login.module.css\");\n/* harmony import */ var _styles_login_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_login_module_css__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\nconst login = ()=>{\n    const [username, setUsername] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const [password, setPassword] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const handleSubmit = (event)=>{\n        event.preventDefault();\n        // Here you would typically make an API request to validate the user's credentials\n        // For simplicity, we will just check if the username and password match a hardcoded value\n        if (username && password) {\n            router.push(\"/admindashboard\") // Push the user to the dashboard page if the credentials are valid\n            ;\n        } else {\n            alert(\"Invalid credentials\");\n        }\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: (_styles_login_module_css__WEBPACK_IMPORTED_MODULE_3___default().logincontainer),\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                    className: (_styles_login_module_css__WEBPACK_IMPORTED_MODULE_3___default().h1),\n                    children: \"Login Page\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\login.js\",\n                    lineNumber: 22,\n                    columnNumber: 7\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"form\", {\n                    className: (_styles_login_module_css__WEBPACK_IMPORTED_MODULE_3___default().form),\n                    onSubmit: handleSubmit,\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"label\", {\n                            className: (_styles_login_module_css__WEBPACK_IMPORTED_MODULE_3___default().label),\n                            children: [\n                                \"Username:\",\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                                    className: (_styles_login_module_css__WEBPACK_IMPORTED_MODULE_3___default().input),\n                                    type: \"text\",\n                                    value: username,\n                                    onChange: (e)=>setUsername(e.target.value)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\login.js\",\n                                    lineNumber: 26,\n                                    columnNumber: 11\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\login.js\",\n                            lineNumber: 24,\n                            columnNumber: 9\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\login.js\",\n                            lineNumber: 28,\n                            columnNumber: 9\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"label\", {\n                            children: [\n                                \"Password:\",\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                                    className: (_styles_login_module_css__WEBPACK_IMPORTED_MODULE_3___default().input),\n                                    type: \"password\",\n                                    value: password,\n                                    onChange: (e)=>setPassword(e.target.value)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\login.js\",\n                                    lineNumber: 31,\n                                    columnNumber: 11\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\login.js\",\n                            lineNumber: 29,\n                            columnNumber: 9\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\login.js\",\n                            lineNumber: 33,\n                            columnNumber: 9\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                            className: (_styles_login_module_css__WEBPACK_IMPORTED_MODULE_3___default().button),\n                            type: \"submit\",\n                            children: \"Login\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\login.js\",\n                            lineNumber: 34,\n                            columnNumber: 9\n                        }, undefined)\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\login.js\",\n                    lineNumber: 23,\n                    columnNumber: 7\n                }, undefined)\n            ]\n        }, void 0, true, {\n            fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\login.js\",\n            lineNumber: 21,\n            columnNumber: 13\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\User-12\\\\Desktop\\\\Event website\\\\my-app\\\\pages\\\\login.js\",\n        lineNumber: 20,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (login);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9sb2dpbi5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQWdDO0FBQ087QUFDUTtBQUMvQyxNQUFNRyxRQUFPLElBQUk7SUFDYixNQUFNLENBQUNDLFVBQVVDLFlBQVksR0FBR0wsK0NBQVFBLENBQUM7SUFDM0MsTUFBTSxDQUFDTSxVQUFVQyxZQUFZLEdBQUdQLCtDQUFRQSxDQUFDO0lBQ3pDLE1BQU1RLFNBQVNQLHNEQUFTQTtJQUV4QixNQUFNUSxlQUFlLENBQUNDLFFBQVU7UUFDOUJBLE1BQU1DLGNBQWM7UUFDcEIsa0ZBQWtGO1FBQ2xGLDBGQUEwRjtRQUMxRixJQUFJUCxZQUFZRSxVQUFVO1lBQ3hCRSxPQUFPSSxJQUFJLENBQUMsbUJBQW1CLG1FQUFtRTs7UUFDcEcsT0FBTztZQUNMQyxNQUFNO1FBQ1IsQ0FBQztJQUNIO0lBQ0UscUJBQ0ksOERBQUNDO2tCQUNHLDRFQUFDQTtZQUFJQyxXQUFXYixnRkFBcUI7OzhCQUMzQyw4REFBQ2U7b0JBQUdGLFdBQVdiLG9FQUFTOzhCQUFFOzs7Ozs7OEJBQzFCLDhEQUFDZ0I7b0JBQUtILFdBQVdiLHNFQUFXO29CQUFFaUIsVUFBVVY7O3NDQUN0Qyw4REFBQ1c7NEJBQU1MLFdBQVdiLHVFQUFZOztnQ0FBRTs4Q0FFOUIsOERBQUNtQjtvQ0FBTU4sV0FBV2IsdUVBQVk7b0NBQUVvQixNQUFLO29DQUFPQyxPQUFPbkI7b0NBQVVvQixVQUFVLENBQUNDLElBQU1wQixZQUFZb0IsRUFBRUMsTUFBTSxDQUFDSCxLQUFLOzs7Ozs7Ozs7Ozs7c0NBRTFHLDhEQUFDSTs7Ozs7c0NBQ0QsOERBQUNQOztnQ0FBTTs4Q0FFTCw4REFBQ0M7b0NBQU1OLFdBQVdiLHVFQUFZO29DQUFFb0IsTUFBSztvQ0FBV0MsT0FBT2pCO29DQUFVa0IsVUFBVSxDQUFDQyxJQUFNbEIsWUFBWWtCLEVBQUVDLE1BQU0sQ0FBQ0gsS0FBSzs7Ozs7Ozs7Ozs7O3NDQUU5Ryw4REFBQ0k7Ozs7O3NDQUNELDhEQUFDQzs0QkFBT2IsV0FBV2Isd0VBQWE7NEJBQUVvQixNQUFLO3NDQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUt4RDtBQUNBLGlFQUFlbkIsS0FBS0EsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL3BhZ2VzL2xvZ2luLmpzPzgxYjAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInXHJcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi4vc3R5bGVzL2xvZ2luLm1vZHVsZS5jc3MnXHJcbmNvbnN0IGxvZ2luID0oKT0+e1xyXG4gICAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgLy8gSGVyZSB5b3Ugd291bGQgdHlwaWNhbGx5IG1ha2UgYW4gQVBJIHJlcXVlc3QgdG8gdmFsaWRhdGUgdGhlIHVzZXIncyBjcmVkZW50aWFsc1xyXG4gICAgLy8gRm9yIHNpbXBsaWNpdHksIHdlIHdpbGwganVzdCBjaGVjayBpZiB0aGUgdXNlcm5hbWUgYW5kIHBhc3N3b3JkIG1hdGNoIGEgaGFyZGNvZGVkIHZhbHVlXHJcbiAgICBpZiAodXNlcm5hbWUgJiYgcGFzc3dvcmQpIHtcclxuICAgICAgcm91dGVyLnB1c2goJy9hZG1pbmRhc2hib2FyZCcpIC8vIFB1c2ggdGhlIHVzZXIgdG8gdGhlIGRhc2hib2FyZCBwYWdlIGlmIHRoZSBjcmVkZW50aWFscyBhcmUgdmFsaWRcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGFsZXJ0KCdJbnZhbGlkIGNyZWRlbnRpYWxzJylcclxuICAgIH1cclxuICB9XHJcbiAgICByZXR1cm4oXHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5sb2dpbmNvbnRhaW5lcn0+XHJcbiAgICAgIDxoMSBjbGFzc05hbWU9e3N0eWxlcy5oMX0+TG9naW4gUGFnZTwvaDE+XHJcbiAgICAgIDxmb3JtIGNsYXNzTmFtZT17c3R5bGVzLmZvcm19IG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxyXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9e3N0eWxlcy5sYWJlbH0+XHJcbiAgICAgICAgICBVc2VybmFtZTpcclxuICAgICAgICAgIDxpbnB1dCBjbGFzc05hbWU9e3N0eWxlcy5pbnB1dH0gdHlwZT1cInRleHRcIiB2YWx1ZT17dXNlcm5hbWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VXNlcm5hbWUoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGxhYmVsPlxyXG4gICAgICAgICAgUGFzc3dvcmQ6XHJcbiAgICAgICAgICA8aW5wdXQgY2xhc3NOYW1lPXtzdHlsZXMuaW5wdXR9IHR5cGU9XCJwYXNzd29yZFwiIHZhbHVlPXtwYXNzd29yZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8YnIgLz5cclxuICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT17c3R5bGVzLmJ1dHRvbn0gdHlwZT1cInN1Ym1pdFwiPkxvZ2luPC9idXR0b24+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIClcclxufVxyXG5leHBvcnQgZGVmYXVsdCBsb2dpblxyXG4iXSwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VSb3V0ZXIiLCJzdHlsZXMiLCJsb2dpbiIsInVzZXJuYW1lIiwic2V0VXNlcm5hbWUiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwicm91dGVyIiwiaGFuZGxlU3VibWl0IiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsInB1c2giLCJhbGVydCIsImRpdiIsImNsYXNzTmFtZSIsImxvZ2luY29udGFpbmVyIiwiaDEiLCJmb3JtIiwib25TdWJtaXQiLCJsYWJlbCIsImlucHV0IiwidHlwZSIsInZhbHVlIiwib25DaGFuZ2UiLCJlIiwidGFyZ2V0IiwiYnIiLCJidXR0b24iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/login.js\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/login.js"));
module.exports = __webpack_exports__;

})();